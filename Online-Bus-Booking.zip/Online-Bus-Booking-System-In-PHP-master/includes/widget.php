<div class="well">
    <h4>Contact Us</h4>
    
    <a href="contact/index.php">Find us Here!</a>
</div>